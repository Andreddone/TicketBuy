// URL del server
const BASE_URL = 'http://localhost:3000';

// Funzione per registrare un nuovo utente
async function registerUser(nome, cognome, telefono, email, psw) {
  try {
    const response = await fetch('/frontend/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, cognome, telefono, email, psw }),
    });

    if (!response.ok) {
      throw new Error('Errore durante la registrazione');
    }

    alert('Registrazione completata con successo!');
    window.location.href = '/'; // Reindirizza alla pagina di login
  } catch (error) {
    alert(error.message);
  }
}

// Funzione per effettuare il login
async function loginUser(nome, psw) {
  try {
    const response = await fetch(`${BASE_URL}/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, psw }), // Usa "nome" e "psw"
    });

    if (!response.ok) {
      throw new Error('Credenziali non valide');
    }

    const data = await response.json();
    localStorage.setItem('token', data.token); // Salva il token nel localStorage
    alert('Login effettuato con successo!');
    window.location.href = '/home'; // Reindirizza alla home
  } catch (error) {
    alert(error.message);
  }
}

// Funzione per accedere a una rotta protetta
async function accessProtectedRoute() {
  const token = localStorage.getItem('token');

  try {
    const response = await fetch(`${BASE_URL}/api/protected`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!response.ok) {
      throw new Error('Accesso negato');
    }

    const data = await response.text();
    document.getElementById('protected-content').innerText = data; // Mostra il contenuto protetto
  } catch (error) {
    alert(error.message);
  }
}

// Event listener per il form di registrazione
if (document.getElementById('register-form')) {
  document.getElementById('register-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Impedisce l'invio predefinito del form

    const nome = document.getElementById('nome').value;
    const cognome = document.getElementById('cognome').value;
    const telefono = document.getElementById('telefono').value;
    const email = document.getElementById('email').value;
    const psw = document.getElementById('psw').value;

    try {
      const response = await fetch('/frontend/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, cognome, telefono, email, psw }),
      });

      if (!response.ok) {
        throw new Error('Errore durante la registrazione');
      }

      alert('Registrazione completata con successo!');
      window.location.href = '/home'; // Reindirizza alla home
    } catch (error) {
      alert(error.message);
    }
  });
}

// Event listener per il form di login
if (document.getElementById('login-form')) {
  document.getElementById('login-form').addEventListener('submit', (event) => {
    event.preventDefault();

    const nome = document.getElementById('username').value;
    const psw = document.getElementById('password').value;

    loginUser(nome, psw);
  });
}

// Carica il contenuto protetto quando necessario
if (document.getElementById('protected-content')) {
  accessProtectedRoute();
}