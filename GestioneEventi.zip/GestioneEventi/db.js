require('dotenv').config();
const mysql = require('mysql2');

// Configura la connessione al database usando le variabili di ambiente
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});

// ...esistente configurazione del database...

connection.connect((err) => {
  if (err) {
    console.error('Errore nella connessione al database:', err.stack);
    return;
  }
  console.log('Connessione al database riuscita!');
});

// ...esistente configurazione del database...

// Funzione per ottenere tutti gli utenti dalla tabella `utenti`
const getUsers = () => {
  return new Promise((resolve, reject) => {
    const query = 'SELECT * FROM utenti';
    connection.query(query, (err, results) => {
      if (err) {
        reject(err);
      }
      resolve(results);
    });
  });
};

// Funzione per salvare un utente nella tabella `utenti`
const saveUser = ({ nome, cognome, telefono, email, psw }) => {
  return new Promise((resolve, reject) => {
    const query = 'INSERT INTO utenti (nome, cognome, telefono, email, psw, ruolo) VALUES (?, ?, ?, ?, ?, ?)';
    const ruolo = 'utente'; // Ruolo predefinito

    connection.query(query, [nome, cognome, telefono, email, psw, ruolo], (err, results) => {
      if (err) {
        console.error('ERRORE DB:', err.code, err.sqlMessage); // Log dell'errore
        reject(new Error(`Errore nel database: ${err.sqlMessage || err.message}`));
        return;
      }
      resolve(results);
    });
  });
};

module.exports = { getUsers, saveUser, connection };

