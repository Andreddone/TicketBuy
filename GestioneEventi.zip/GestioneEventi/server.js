require('dotenv').config();
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { getUsers, saveUser, connection } = require('./db'); // Importa saveUser
const app = express();

app.use(express.json()); // Per gestire il body delle richieste JSON
app.use(express.urlencoded({ extended: true })); // Per gestire i dati inviati dai form HTML

const SECRET_KEY = process.env.SECRET_KEY; // Usa la chiave segreta dal file .env
const PORT = process.env.PORT || 3000; // Usa la porta dal file .env

// Configura una route per ottenere gli utenti dal database
app.get('/api/users', async (req, res) => {
  console.log('Richiesta ricevuta su /api/users');
  try {
    const users = await getUsers(); // Ottieni gli utenti dal DB usando la funzione getUsers
    console.log('Utenti recuperati:', users);
    res.json(users); // Restituisci i risultati come JSON
  } catch (error) {
    console.error('Errore durante la query:', error.stack);
    res.status(500).send('Errore nel recupero dei dati');
  }
});

// Serve i file statici dalla cartella 'frontend'
app.use(express.static('frontend'));
app.use('/backend', express.static('backend'));

// Serve il file HTML per la registrazione
app.get('/frontend/register', (req, res) => {
  console.log('Richiesta ricevuta su /frontend/register');
  res.sendFile(__dirname + '/frontend/register.html');
});

// Gestisce la registrazione degli utenti
app.post('/frontend/register', async (req, res) => {
  console.log('Richiesta POST ricevuta su /frontend/register');
  try {
    console.log('Dati ricevuti:', req.body);

    const { nome, cognome, telefono, email, psw } = req.body;

    if (!nome || !cognome || !telefono || !email || !psw) {
      console.error('Dati mancanti nel corpo della richiesta');
      return res.status(400).send('Dati mancanti nel corpo della richiesta');
    }

    // Controlla se l'email esiste già nel database
    const [existingUser] = await connection.promise().query(
      'SELECT * FROM utenti WHERE email = ?',
      [email]
    );

    console.log('Utenti esistenti con questa email:', existingUser);

    if (existingUser.length > 0) {
      console.log('Utente già registrato con questa email');
      return res.status(400).send('Utente già registrato con questa email');
    }

    // Controllo per evitare duplicati in caso di richieste simultanee
    const hashedPassword = await bcrypt.hash(psw, 10);
    console.log('Password crittografata:', hashedPassword);

    await saveUser({ nome, cognome, telefono, email, psw: hashedPassword });
    console.log('Utente registrato con successo');

    res.status(201).send('Registrazione completata con successo');
  } catch (error) {
    console.error('Errore durante la registrazione:', error.message);
    res.status(500).send(`Errore nella registrazione: ${error.message}`);
  }
});

// Endpoint per il login
app.post('/api/login', async (req, res) => {
  console.log('Richiesta POST ricevuta su /api/login');
  const { nome, psw } = req.body;

  try {
    console.log('Dati ricevuti per il login:', { nome, psw });

    connection.query(
      'SELECT * FROM utenti WHERE nome = ?',
      [nome],
      async (err, results) => {
        if (err) {
          console.error('Errore durante la query:', err.stack);
          return res.status(500).send('Errore del server');
        }

        console.log('Risultati della query per il login:', results);

        if (results.length === 0) {
          console.log('Utente non trovato:', nome);
          return res.status(401).send('Credenziali non valide');
        }

        const user = results[0];
        const isPasswordValid = await bcrypt.compare(psw, user.psw);

        console.log('Risultato del confronto password:', isPasswordValid);

        if (!isPasswordValid) {
          console.log('Password non valida per utente:', nome);
          return res.status(401).send('Credenziali non valide');
        }

        const token = jwt.sign({ id: user.id, username: user.nome }, SECRET_KEY, {
          expiresIn: '1h',
        });

        console.log('Token generato:', token);

        res.json({ token });
      }
    );
  } catch (error) {
    console.error('Errore durante il login:', error.stack);
    res.status(500).send('Errore del server');
  }
});

// Middleware per proteggere le rotte
const authenticateToken = (req, res, next) => {
  console.log('Middleware authenticateToken chiamato');
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) {
    console.error('Token non fornito');
    return res.status(401).send('Accesso negato');
  }

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) {
      console.error('Token non valido:', err.message);
      return res.status(403).send('Token non valido');
    }
    console.log('Token verificato con successo:', user);
    req.user = user;
    next();
  });
};

// Rotta protetta
app.get('/api/protected', authenticateToken, (req, res) => {
  console.log('Accesso alla rotta protetta da parte di:', req.user);
  res.send(`Benvenuto, ${req.user.username}`);
});

// Route per la home (puoi usare questa route per caricare index.html)
app.get('/', (req, res) => {
  console.log('Richiesta ricevuta su /');
  res.sendFile(__dirname + '/frontend/index.html');
});

// Route per la home
app.get('/home', (req, res) => {
  console.log('Richiesta ricevuta su /home');
  res.sendFile(__dirname + '/backend/home.html');
});

// Route per ottenere i tipi dalla tabella categorie
app.get('/api/categorie', async (req, res) => {
  console.log('Richiesta ricevuta su /api/categorie');
  try {
    const [rows] = await connection.promise().query('SELECT tipo FROM categorie');
    console.log('Categorie recuperate:', rows);
    res.json(rows); // Restituisci i tipi come JSON
  } catch (error) {
    console.error('Errore durante il recupero delle categorie:', error.message);
    res.status(500).send('Errore nel recupero delle categorie');
  }
});

// Route per ottenere eventi filtrati
app.get('/api/eventi', async (req, res) => {
  console.log('Richiesta ricevuta su /api/eventi con query:', req.query);
  const { tipo, data } = req.query;

  try {
    const query = `
      SELECT eventi.nome, eventi.ora 
      FROM eventi 
      JOIN categorie ON eventi.id_categoria = categorie.id 
      WHERE categorie.tipo = ? AND eventi.data_e = ?
    `;
    const [rows] = await connection.promise().query(query, [tipo, data]);
    console.log('Eventi filtrati recuperati:', rows);
    res.json(rows); // Restituisci i nomi e le ore degli eventi come JSON
  } catch (error) {
    console.error('Errore durante il recupero degli eventi:', error.message);
    res.status(500).send('Errore nel recupero degli eventi');
  }
});

// Avvia il server
app.listen(PORT, () => {
  console.log(`Server Express in esecuzione su http://localhost:${PORT}`);
});

app.get('/test-db', async (req, res) => {
  console.log('Richiesta ricevuta su /test-db');
  connection.query('SELECT 1', (err, results) => {
    if (err) {
      console.error('Errore nella connessione al database:', err.message);
      res.status(500).send('Errore nella connessione al database');
      return;
    }
    console.log('Connessione al database riuscita:', results);
    res.status(200).send('Connessione al database riuscita!');
  });
});